import SwiftUI

struct AnswersView: View {
    let questions: [Question]
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                ForEach(questions.indices, id: \.self) { index in
                    let question = questions[index]
                    VStack(alignment: .leading) {
                        Text("Question \(index + 1): \(question.text)")
                            .font(.headline)
                        Text("Correct Answer: \(question.correctAnswer)")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                }
            }
            .padding()
        }
    }
}
