import SwiftUI

struct Question {
    let text: String
    let answers: [String]
    let correctAnswer: String
}

struct ContentView: View {
    let questions = [
        Question(text: "What is the meaning of the word 'meticulous'?", answers: ["A. Careless", "B. Precise and thorough", "C. Indifferent", "D. Haphazard"], correctAnswer: "B. Precise and thorough"),
        Question(text: "What is the synonym of the word 'benevolent'?", answers: ["A. Malevolent", "B. Kind-hearted", "C. Apathetic", "D. Cruel"], correctAnswer: "B. Kind-hearted"),
        Question(text: "What does the word 'lucid' imply?", answers: ["A. Confusing", "B. Muddled", "C. Clear and easily understood", "D. Vague"], correctAnswer: "C. Clear and easily understood"),
        Question(text: "What is the antonym of the word 'diligent'?", answers: ["A. Hardworking", "B. Lazy", "C. Industrious", "D. Diligent"], correctAnswer: "B. Lazy"),
        Question(text: "What is the definition of 'reverence'?", answers: ["A. Disrespect", "B. Deep respect and admiration", "C. Antipathy", "D. Hostility"], correctAnswer: "B. Deep respect and admiration"),
        Question(text: "What is the synonym of the word 'pinnacle'?", answers: ["A. Summit", "B. Trough", "C. Valley", "D. Base"], correctAnswer: "A. Summit"),
        Question(text: "What does the word 'affluent' mean?", answers: ["A. Poor", "B. Wealthy", "C. Indebted", "D. Destitute"], correctAnswer: "B. Wealthy"),
        Question(text: "What is the meaning of the word 'engross'?", answers: ["A. Bore", "B. Distract", "C. Absorb all the attention or interest of", "D. Ignore"], correctAnswer: "C. Absorb all the attention or interest of"),
        Question(text: "What is the synonym of the word 'resilient'?", answers: ["A. Fragile", "B. Strong and flexible", "C. Weak", "D. Brittle"], correctAnswer: "B. Strong and flexible"),
        Question(text: "What does the term 'conscientious' signify?", answers: ["A. Careless", "B. Unreliable", "C. Diligent and thorough", "D. Negligent"], correctAnswer: "C. Diligent and thorough"),
        Question(text: "What is the antonym of the word 'arduous'?", answers: ["A. Easy", "B. Simple", "C. Effortless", "D. Facile"], correctAnswer: "A. Easy"),
        Question(text: "What is the definition of 'prolific'?", answers: ["A. Unproductive", "B. Fruitful and abundant", "C. Barren", "D. Infertile"], correctAnswer: "B. Fruitful and abundant"),
        Question(text: "What is the synonym of the word 'voracious'?", answers: ["A. Indifferent", "B. Greedy", "C. Apathetic", "D. Sated"], correctAnswer: "B. Greedy"),
        Question(text: "What does the word 'inquisitive' imply?", answers: ["A. Curious and eager to learn", "B. Disinterested", "C. Indifferent", "D. Apathetic"], correctAnswer: "A. Curious and eager to learn"),
        Question(text: "What is the meaning of the word 'exemplary'?", answers: ["A. Faulty", "B. Commendable and worthy of imitation", "C. Mediocre", "D. Defective"], correctAnswer: "B. Commendable and worthy of imitation")
    ]
    
    @State private var currentQuestionIndex = 0
    @State private var selectedAnswer: String?
    @State private var score = 0
    @State private var showAnswers = false
    @State private var timeRemaining = 10
    @State private var timerPaused = false
    @State private var quizStarted = false
    
    var body: some View {
        if quizStarted {
            VStack {
                VStack {
                    Text("WordWise")
                        .font(.title)
                        .foregroundColor(.white)
                    Divider()
                        .frame(width: 160, height: 2)
                        .overlay(Color.white)
                        .padding(.top, -17)
                    Text("Expand Your Lexicon, One Word at a Time.")
                        .foregroundColor(.white)
                        .font(.subheadline)
                        .padding(.top, -20)
                }
                .padding()
                
                Divider()
                
                Text("Question \(currentQuestionIndex + 1) of \(questions.count)")
                    .font(.headline)
                    .padding()
                
                TimerBar(timeRemaining: $timeRemaining)
                    .padding(.bottom, 10)
                
                if currentQuestionIndex < questions.count {
                    QuestionView(question: questions[currentQuestionIndex], selectedAnswer: $selectedAnswer) { selected in
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            self.handleAnswer(selected)
                        }
                    }
                    .padding()
                    .onAppear(perform: startTimer)
                    .onReceive(Timer.publish(every: 1, on: .main, in: .default).autoconnect(), perform: { _ in
                        if !timerPaused {
                            if timeRemaining > 0 {
                                timeRemaining -= 1
                            } else {
                                nextQuestion()
                                startTimer()
                            }
                        }
                    })
                    .onChange(of: currentQuestionIndex) { _ in
                        timeRemaining = 10
                    }
                } else {
                    ResultView(score: score, totalQuestions: questions.count, restartQuiz: restartQuiz, showAnswers: $showAnswers, questions: questions)
                }
                
                Spacer()
                
                Button(action: skipQuiz) {
                    Text("Skip >")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(8)
                        .padding(.bottom, 20)
                        .padding(.trailing, 20)
                    
                } 
                
                Spacer()
            }
        } else {
            IntroView(startQuiz: startQuiz)
        }
    }
    
    private func handleAnswer(_ selected: String?) {
        if let selectedAnswer = selected {
            if selectedAnswer == questions[currentQuestionIndex].correctAnswer {
                score += 1
            }
        }
        selectedAnswer = nil
        currentQuestionIndex += 1
        timeRemaining = 10
    }
    
    private func restartQuiz() {
        currentQuestionIndex = 0
        score = 0
        selectedAnswer = nil
    }
    
    private func skipQuiz() {
        currentQuestionIndex += 1
        if currentQuestionIndex >= questions.count {
            currentQuestionIndex = 0
        }
        timeRemaining = 10
    }
    
    private func nextQuestion() {
        currentQuestionIndex += 1
        if currentQuestionIndex >= questions.count {
            currentQuestionIndex = 0
        }
        timeRemaining = 10
    }
    
    private func startTimer() {
        timerPaused = false
        timeRemaining = 10
    }
    
    private func startQuiz() {
        quizStarted = true
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
