import SwiftUI

struct ResultView: View {
    let score: Int
    let totalQuestions: Int
    let restartQuiz: () -> Void
    @Binding var showAnswers: Bool
    let questions: [Question]
    
    var body: some View {
        VStack {
            Text("Quiz Result")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.blue)
                .padding(.bottom, 20)
            
            Text("You scored \(score) out of \(totalQuestions)")
                .font(.title)
                .foregroundColor(.black)
                .padding(.bottom, 40)
            
            Button(action: {
                showAnswers.toggle()
            }) {
                Text("Show Answers")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding(.horizontal, 40)
            
            if showAnswers {
                AnswersView(questions: questions)
            }
            
            Button(action: restartQuiz) {
                Text("Restart Quiz")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding(.horizontal, 40)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 20)
                .foregroundColor(.white)
                .shadow(color: Color.gray.opacity(0.4), radius: 5, x: 0, y: 2)
        )
        .padding(40)
    }
}
