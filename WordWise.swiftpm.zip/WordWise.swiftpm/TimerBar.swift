import SwiftUI

struct TimerBar: View {
    @Binding var timeRemaining: Int
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Rectangle()
                    .foregroundColor(.gray)
                    .opacity(0.3)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .cornerRadius(45.0)
                
                Rectangle()
                    .foregroundColor(.blue)
                    .frame(width: CGFloat(timeRemaining) / 10 * geometry.size.width, height: geometry.size.height)
                    .animation(.linear(duration: 1))
                    .cornerRadius(45.0)
            }
        }
        .frame(height: 10)
    }
}
