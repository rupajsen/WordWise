import SwiftUI

struct IntroView: View {
    let startQuiz: () -> Void
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack {
                Spacer()
                
                Text("WordWise")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                Divider()
                    .frame(width: 160, height: 2)
                    .overlay(Color.white)
                    .padding(.top, -17)
                Text("Expand Your Lexicon, One Word at a Time")
                    .font(.title)
                    .foregroundColor(.white)
                    .padding(.top, 20)
                Spacer()
                Image("quiz") 
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 500, height: 500)
                    .padding(.bottom, 40)
                    .offset(y: -70)
                
                
                Button(action: startQuiz) {
                    Text("Start Quiz")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .padding(.horizontal, 40)
                        .padding(.bottom, 20)
                }
                .offset(y: -50)
                Spacer()
            }
            .padding()
        }
    }
}
