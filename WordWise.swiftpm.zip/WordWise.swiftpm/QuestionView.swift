import SwiftUI

struct QuestionView: View {
    let question: Question
    @Binding var selectedAnswer: String?
    var onAnswerSelected: ((String?) -> Void)
    
    var body: some View {
        VStack {
            Text(question.text)
                .font(.title)
                .padding()
            
            ForEach(question.answers, id: \.self) { answer in
                Button(action: {
                    selectedAnswer = answer
                    onAnswerSelected(answer)
                }) {
                    Text(answer)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(
                            selectedAnswer == answer ? Color(
                                answer == question.correctAnswer ? .green : .red
                            ) : Color.blue
                        )
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding(.vertical, 5)
            }
        }
    }
}
